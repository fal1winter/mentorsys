-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: mentor_system
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL COMMENT '学生ID',
  `mentor_id` int NOT NULL COMMENT '导师ID',
  `status` varchar(50) DEFAULT 'pending' COMMENT '状态: pending, accepted, rejected, withdrawn',
  `application_letter` text COMMENT '申请信',
  `research_proposal` text COMMENT '研究计划',
  `student_message` text COMMENT '学生留言',
  `mentor_feedback` text COMMENT '导师反馈',
  `apply_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `response_time` datetime DEFAULT NULL COMMENT '回复时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_mentor_id` (`mentor_id`),
  KEY `idx_status` (`status`),
  KEY `idx_apply_time` (`apply_time`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`mentor_id`) REFERENCES `mentors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='申请匹配表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (2,2,1,'accepted','11','11','1','ok','2026-02-04 17:48:29','2026-02-04 17:49:42','2026-02-04 17:48:29','2026-02-04 17:49:42'),(3,6,1,'accepted','我喜欢学习','我喜欢学习','','','2026-02-09 19:31:49','2026-02-09 19:32:32','2026-02-09 19:31:49','2026-02-09 19:32:31');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browsing_history`
--

DROP TABLE IF EXISTS `browsing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `browsing_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户ID',
  `user_type` varchar(20) NOT NULL COMMENT '用户类型: student, mentor',
  `target_type` varchar(50) NOT NULL COMMENT '目标类型: mentor, publication, application',
  `target_id` int NOT NULL COMMENT '目标ID',
  `action_type` varchar(50) NOT NULL COMMENT '行为类型: view, search, apply, rate',
  `duration_seconds` int DEFAULT NULL COMMENT '停留时长(秒)',
  `additional_data` json DEFAULT NULL COMMENT '额外数据',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target` (`target_type`,`target_id`),
  KEY `idx_action` (`action_type`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='浏览历史表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browsing_history`
--

LOCK TABLES `browsing_history` WRITE;
/*!40000 ALTER TABLE `browsing_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `browsing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `application_id` int DEFAULT NULL COMMENT '关联申请ID（可选）',
  `student_id` int DEFAULT NULL COMMENT '学生ID',
  `mentor_id` int DEFAULT NULL COMMENT '导师ID',
  `sender_id` int NOT NULL COMMENT '发送者ID',
  `sender_type` varchar(20) NOT NULL COMMENT '发送者类型: student, mentor',
  `message_type` varchar(50) DEFAULT 'text' COMMENT '消息类型: text, file, image',
  `content` text COMMENT '消息内容',
  `file_url` varchar(500) DEFAULT NULL COMMENT '文件URL',
  `is_read` tinyint(1) DEFAULT '0' COMMENT '是否已读',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_application_id` (`application_id`),
  KEY `idx_sender` (`sender_id`,`sender_type`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_student_mentor` (`student_id`,`mentor_id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='聊天消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (1,2,2,1,7,'STUDENT','TEXT','hh',NULL,0,'2026-02-04 20:19:04'),(2,2,2,1,7,'STUDENT','TEXT','hjl',NULL,0,'2026-02-04 20:19:15'),(3,2,2,1,7,'STUDENT','TEXT','看到',NULL,0,'2026-02-04 20:30:38'),(4,2,2,1,7,'STUDENT','TEXT','wow',NULL,0,'2026-02-04 20:30:58'),(5,2,2,1,7,'STUDENT','TEXT','woe',NULL,0,'2026-02-04 20:31:01'),(6,2,2,1,7,'STUDENT','TEXT','1',NULL,0,'2026-02-04 20:31:13'),(7,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:14'),(8,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:15'),(9,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:15'),(10,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:16'),(11,2,2,1,7,'STUDENT','TEXT','\n11',NULL,0,'2026-02-04 20:31:16'),(12,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:16'),(13,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:16'),(14,2,2,1,7,'STUDENT','TEXT','\n1',NULL,0,'2026-02-04 20:31:17'),(15,2,2,1,7,'STUDENT','TEXT','2',NULL,0,'2026-02-04 20:37:51'),(16,2,2,1,7,'STUDENT','TEXT','3',NULL,0,'2026-02-04 20:37:54'),(17,NULL,7,1,3,'MENTOR','TEXT','1',NULL,0,'2026-02-06 16:05:25'),(18,NULL,7,1,3,'MENTOR','TEXT','1',NULL,0,'2026-02-06 16:05:26'),(19,NULL,7,1,3,'MENTOR','TEXT','12',NULL,0,'2026-02-06 16:05:29'),(20,NULL,7,1,3,'MENTOR','TEXT','hei',NULL,0,'2026-02-08 13:54:37'),(21,NULL,7,1,3,'MENTOR','TEXT','ha',NULL,0,'2026-02-08 13:54:40'),(22,NULL,4,1,3,'MENTOR','TEXT','hh',NULL,0,'2026-02-08 19:10:39'),(23,NULL,4,1,9,'STUDENT','TEXT','wow',NULL,0,'2026-02-08 20:12:38'),(24,NULL,4,5,9,'STUDENT','TEXT','👋',NULL,0,'2026-02-08 20:37:30'),(25,NULL,4,1,9,'STUDENT','TEXT','hh',NULL,0,'2026-02-08 21:00:01'),(26,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:02'),(27,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:03'),(28,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:04'),(29,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:07'),(30,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:08'),(31,NULL,4,1,9,'STUDENT','TEXT','h',NULL,0,'2026-02-08 21:00:09'),(32,NULL,16,3,3,'MENTOR','TEXT','hello',NULL,0,'2026-02-09 19:27:19'),(33,NULL,6,1,3,'MENTOR','TEXT','你好，欢迎加入我的组',NULL,0,'2026-02-09 19:33:03'),(34,NULL,6,1,17,'STUDENT','TEXT','hh',NULL,0,'2026-02-09 19:34:25'),(35,3,6,1,17,'STUDENT','TEXT','hh',NULL,0,'2026-02-09 19:34:51'),(36,NULL,6,1,17,'STUDENT','TEXT','你好',NULL,0,'2026-02-10 13:54:52');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keywords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '关键词名称',
  `description` text COMMENT '关键词简介',
  `category` varchar(50) DEFAULT NULL COMMENT '分类',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='研究方向关键词表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keywords`
--

LOCK TABLES `keywords` WRITE;
/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
INSERT INTO `keywords` VALUES (1,'深度学习','deep learning','人工智能','2026-02-04 13:28:48','2026-02-04 13:28:48'),(2,'mlp','全连接层','','2026-02-04 16:18:25','2026-02-04 16:18:25');
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mentor_scholars`
--

DROP TABLE IF EXISTS `mentor_scholars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mentor_scholars` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '关联ID',
  `mentor_id` int NOT NULL COMMENT '导师ID',
  `scholar_id` int NOT NULL COMMENT '学者ID',
  `verified` tinyint(1) DEFAULT '0' COMMENT '是否已验证',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mentor_scholar` (`mentor_id`,`scholar_id`),
  KEY `idx_mentor_id` (`mentor_id`),
  KEY `idx_scholar_id` (`scholar_id`),
  CONSTRAINT `fk_mentor_scholars_mentor` FOREIGN KEY (`mentor_id`) REFERENCES `mentors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mentor_scholars_scholar` FOREIGN KEY (`scholar_id`) REFERENCES `scholars` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='导师-学者关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mentor_scholars`
--

LOCK TABLES `mentor_scholars` WRITE;
/*!40000 ALTER TABLE `mentor_scholars` DISABLE KEYS */;
/*!40000 ALTER TABLE `mentor_scholars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mentors`
--

DROP TABLE IF EXISTS `mentors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mentors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL COMMENT '关联用户ID (from users table)',
  `name` varchar(100) NOT NULL COMMENT '导师姓名',
  `title` varchar(100) DEFAULT NULL COMMENT '职称 (Professor, Associate Professor, etc.)',
  `institution` varchar(200) DEFAULT NULL COMMENT '所属机构',
  `department` varchar(200) DEFAULT NULL COMMENT '院系',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(50) DEFAULT NULL COMMENT '电话',
  `office_location` varchar(200) DEFAULT NULL COMMENT '办公室位置',
  `research_areas` json DEFAULT NULL COMMENT '研究方向列表 ["AI", "Machine Learning"]',
  `keywords` json DEFAULT NULL COMMENT '关键词列表',
  `bio` text COMMENT '个人简介',
  `group_direction` text COMMENT '组内研究方向',
  `expected_student_qualities` text COMMENT '期望学生素质',
  `mentoring_style` varchar(500) DEFAULT NULL COMMENT '指导风格',
  `available_positions` int DEFAULT '0' COMMENT '可用名额',
  `funding_status` varchar(200) DEFAULT NULL COMMENT '经费状况',
  `collaboration_opportunities` text COMMENT '合作机会',
  `education_background` text COMMENT '教育背景',
  `avatar` varchar(500) DEFAULT NULL COMMENT '头像URL',
  `homepage_url` varchar(500) DEFAULT NULL COMMENT '个人主页',
  `google_scholar_url` varchar(500) DEFAULT NULL COMMENT 'Google Scholar链接',
  `accepting_students` tinyint(1) DEFAULT '1' COMMENT '是否接收学生',
  `max_students` int DEFAULT '5' COMMENT '最多接收学生数',
  `current_students` int DEFAULT '0' COMMENT '当前学生数',
  `rating_avg` decimal(3,2) DEFAULT '0.00' COMMENT '平均评分',
  `rating_count` int DEFAULT '0' COMMENT '评分数量',
  `view_count` int DEFAULT '0' COMMENT '浏览次数',
  `status` tinyint DEFAULT '1' COMMENT '状态 (0=禁用, 1=启用)',
  `is_verified` tinyint(1) DEFAULT '0' COMMENT '是否认证',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_institution` (`institution`),
  KEY `idx_rating` (`rating_avg`),
  KEY `idx_status` (`status`),
  CONSTRAINT `mentors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='导师信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mentors`
--

LOCK TABLES `mentors` WRITE;
/*!40000 ALTER TABLE `mentors` DISABLE KEYS */;
INSERT INTO `mentors` VALUES (1,3,'李翔x','','动力研究所','','a1@163.com',NULL,'','[\"人工智能\", \"机器学习\"]','[\"NLP\"]','这是一位示例导师','大语言模型应用研究','具有扎实的数学基础,必须过英语六级','每周组会，鼓励自主探索',3,'国家自然科学基金',NULL,'',NULL,'','',1,5,2,8.00,1,120,1,0,'2026-02-03 18:24:20','2026-02-25 11:27:07'),(2,NULL,'Alex',NULL,'xg',NULL,'alex@163.com',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0.00,0,4,1,NULL,'2026-02-04 12:31:40','2026-02-04 19:49:18'),(3,NULL,'kalios',NULL,'kaka',NULL,'kalios@163.com',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0.00,0,4,1,NULL,'2026-02-04 16:06:53','2026-02-04 16:29:35'),(4,NULL,'交交',NULL,'xj',NULL,'xj@163.com',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0.00,0,4,1,NULL,'2026-02-04 16:17:59','2026-02-10 13:28:27'),(5,NULL,'张明教授','教授','清华大学','计算机科学与技术系','zhangming@tsinghua.edu.cn',NULL,NULL,'[\"深度学习\", \"自然语言处理\", \"大语言模型\", \"知识图谱\"]','[\"NLP\", \"LLM\", \"Transformer\", \"BERT\", \"GPT\"]','张明教授是清华大学计算机系教授，博士生导师，主要研究方向为自然语言处理和大语言模型。在ACL、EMNLP、NAACL等顶级会议发表论文50余篇，Google Scholar引用超过10000次。','组内主要研究大语言模型的预训练、微调和应用，包括：1）大模型高效训练方法；2）模型压缩与加速；3）多模态大模型；4）大模型安全与对齐','期望学生具有扎实的数学基础和编程能力，熟悉深度学习框架，有NLP相关研究经验者优先。要求学生具有独立思考能力和良好的团队协作精神。','采用导师-学生双向交流模式，每周组会讨论，鼓励学生自主探索研究方向，提供充足的计算资源和学术交流机会。',3,'国家自然科学基金重点项目、企业合作项目','与微软亚洲研究院、阿里达摩院有长期合作',NULL,NULL,NULL,NULL,1,5,2,4.80,25,15,1,1,'2026-02-07 19:13:03','2026-02-10 21:12:48'),(6,NULL,'李华副教授','副教授','北京大学','人工智能研究院','lihua@pku.edu.cn',NULL,NULL,'[\"计算机视觉\", \"图像识别\", \"目标检测\", \"视频理解\"]','[\"CV\", \"CNN\", \"YOLO\", \"Transformer\", \"ViT\"]','李华副教授专注于计算机视觉领域研究，在CVPR、ICCV、ECCV等顶级会议发表论文30余篇。研究成果已应用于自动驾驶、医疗影像等领域。','组内研究方向包括：1）高效目标检测算法；2）视频理解与行为识别；3）医疗影像分析；4）3D视觉感知','期望学生对计算机视觉有浓厚兴趣，具备良好的数学基础和编程能力，有竞赛经验或论文发表经验者优先。','注重培养学生的独立研究能力，提供一对一指导，鼓励参加学术会议和企业实习。',2,'国家重点研发计划、华为合作项目','与商汤科技、旷视科技有项目合作',NULL,NULL,NULL,NULL,1,4,2,4.60,18,4,1,1,'2026-02-07 19:13:03','2026-02-09 19:09:03'),(7,NULL,'王强教授','教授','浙江大学','计算机学院','wangqiang@zju.edu.cn',NULL,NULL,'[\"机器学习\", \"强化学习\", \"推荐系统\", \"数据挖掘\"]','[\"ML\", \"RL\", \"RecSys\", \"Graph Neural Network\", \"AutoML\"]','王强教授是浙江大学计算机学院教授，ACM杰出科学家。主要研究机器学习理论与应用，在KDD、ICML、NeurIPS等顶级会议发表论文60余篇。','组内研究方向：1）图神经网络理论与应用；2）强化学习算法；3）大规模推荐系统；4）自动机器学习','期望学生具有扎实的数学基础（线性代数、概率论、优化理论），熟练掌握Python和深度学习框架，有科研热情。','采用项目驱动的培养模式，学生可参与实际工业项目，提供丰富的学术资源和国际交流机会。',4,'阿里巴巴合作项目、国家自然科学基金','与阿里巴巴、字节跳动有深度合作',NULL,NULL,NULL,NULL,1,6,2,4.70,32,7,1,1,'2026-02-07 19:13:03','2026-02-09 19:09:19'),(8,NULL,'陈静研究员','研究员','中国科学院计算所','智能信息处理实验室','chenjing@ict.ac.cn',NULL,NULL,'[\"知识图谱\", \"信息抽取\", \"问答系统\", \"语义理解\"]','[\"Knowledge Graph\", \"Information Extraction\", \"QA\", \"Semantic Web\"]','陈静研究员专注于知识图谱和语义理解研究，主持多项国家级科研项目，在WWW、SIGIR、AAAI等会议发表论文40余篇。','组内研究：1）大规模知识图谱构建；2）开放域问答系统；3）事件抽取与推理；4）知识增强的语言模型','期望学生具有NLP或知识工程背景，有较强的工程实现能力，能够独立完成系统开发。','提供宽松的研究环境，鼓励学生探索前沿问题，支持参加国际学术会议。',2,'国家重点研发计划、中科院先导专项','与百度、腾讯有合作项目',NULL,NULL,NULL,NULL,1,4,2,4.50,15,3,1,1,'2026-02-07 19:13:03','2026-02-09 23:31:10'),(9,NULL,'刘洋教授','教授','上海交通大学','电子信息与电气工程学院','liuyang@sjtu.edu.cn',NULL,NULL,'[\"语音识别\", \"语音合成\", \"多模态学习\", \"人机交互\"]','[\"ASR\", \"TTS\", \"Multimodal\", \"Speech\", \"Audio\"]','刘洋教授是语音技术领域专家，在ICASSP、Interspeech等会议发表论文50余篇，多项技术成果已产业化应用。','组内方向：1）端到端语音识别；2）个性化语音合成；3）语音情感识别；4）多模态对话系统','期望学生对语音信号处理有兴趣，具备信号处理或深度学习基础，有相关项目经验者优先。','注重理论与实践结合，提供丰富的工业界实习机会，培养学生的工程能力。',3,'科大讯飞合作项目、国家自然科学基金','与科大讯飞、小米有长期合作',NULL,NULL,NULL,NULL,1,5,2,4.40,20,6,1,1,'2026-02-07 19:13:03','2026-02-10 22:53:07'),(10,NULL,'赵伟教授','教授','北京大学','信息科学技术学院','zhao@pku.edu.cn',NULL,NULL,'[\"计算机视觉\", \"图像处理\", \"三维重建\", \"SLAM\"]','[\"CV\", \"3D Vision\", \"SLAM\", \"NeRF\", \"Gaussian Splatting\"]','赵伟教授是北京大学信息科学技术学院教授，主要研究计算机视觉和三维重建。在CVPR、ICCV、ECCV等顶级会议发表论文40余篇。','组内主要研究方向：1）神经辐射场与三维重建；2）视觉SLAM；3）多视图几何；4）自动驾驶感知','期望学生具有扎实的数学基础（线性代数、优化理论），熟悉C++和Python，有计算机视觉相关项目经验者优先。','每周一对一讨论，鼓励学生参与实际项目，提供充足的GPU计算资源。',4,'国家自然科学基金面上项目、华为合作项目','与华为、商汤科技有深度合作',NULL,NULL,NULL,NULL,1,6,2,4.75,28,16,1,1,'2026-02-08 21:51:05','2026-02-10 14:01:09'),(11,NULL,'孙明研究员','研究员','复旦大学','计算机科学技术学院','sun@fudan.edu.cn',NULL,NULL,'[\"自然语言处理\", \"对话系统\", \"情感分析\", \"文本生成\"]','[\"NLP\", \"Dialogue\", \"Sentiment\", \"Text Generation\", \"ChatBot\"]','孙明研究员是复旦大学计算机学院研究员，专注于自然语言处理和对话系统研究。在ACL、EMNLP等会议发表论文35篇。','组内研究方向：1）大模型对话系统；2）情感计算；3）多轮对话理解；4）知识增强的文本生成','期望学生对NLP有浓厚兴趣，具备良好的编程能力，有论文发表经验者优先。','采用小组讨论与个人指导相结合的方式，每周组会，鼓励学生参加学术会议。',3,'国家重点研发计划、腾讯合作项目','与腾讯AI Lab、百度NLP有合作',NULL,NULL,NULL,NULL,1,5,1,4.65,22,12,1,1,'2026-02-08 21:51:05','2026-02-08 21:51:05'),(12,NULL,'吴刚教授','教授','南京大学','人工智能学院','wu@nju.edu.cn',NULL,NULL,'[\"强化学习\", \"多智能体系统\", \"博弈论\", \"机器人控制\"]','[\"RL\", \"Multi-Agent\", \"Game Theory\", \"Robotics\", \"Decision Making\"]','吴刚教授是南京大学人工智能学院教授，主要研究强化学习和多智能体系统。在NeurIPS、ICML、ICLR发表论文45篇。','组内研究方向：1）深度强化学习算法；2）多智能体协作与竞争；3）机器人运动控制；4）自动驾驶决策','期望学生具有扎实的数学基础，熟悉强化学习基本算法，有编程实现能力。','注重理论与实践结合，提供机器人实验平台，支持学生参加机器人竞赛。',3,'国家自然科学基金重点项目、大疆合作项目','与大疆、蔚来汽车有合作',NULL,NULL,NULL,NULL,1,5,2,4.00,1,22,1,1,'2026-02-08 21:51:05','2026-02-10 13:56:56'),(13,NULL,'周芳副教授','副教授','中国科学技术大学','计算机科学与技术学院','zhou@ustc.edu.cn',NULL,NULL,'[\"数据挖掘\", \"社交网络分析\", \"推荐系统\", \"用户行为分析\"]','[\"Data Mining\", \"Social Network\", \"RecSys\", \"User Behavior\", \"Graph Mining\"]','周芳副教授是中科大计算机学院副教授，主要研究数据挖掘和社交网络分析。在KDD、WWW、WSDM发表论文30篇。','组内研究方向：1）图神经网络与社交网络；2）个性化推荐算法；3）用户行为建模；4）在线学习','期望学生具有良好的数学基础和编程能力，对数据分析有兴趣，有竞赛经验者优先。','采用项目驱动的培养模式，学生可参与实际数据分析项目，提供丰富的数据资源。',2,'国家自然科学基金青年项目、字节跳动合作项目','与字节跳动、快手有合作',NULL,NULL,NULL,NULL,1,4,1,4.55,18,10,1,1,'2026-02-08 21:51:05','2026-02-08 21:51:05'),(14,NULL,'郑涛教授','教授','哈尔滨工业大学','计算学部','zheng@hit.edu.cn',NULL,NULL,'[\"知识图谱\", \"信息抽取\", \"问答系统\", \"语义理解\"]','[\"Knowledge Graph\", \"IE\", \"QA\", \"Semantic\", \"Entity Linking\"]','郑涛教授是哈工大计算学部教授，主要研究知识图谱和信息抽取。在ACL、EMNLP、NAACL发表论文50余篇。','组内研究方向：1）大规模知识图谱构建；2）开放域信息抽取；3）知识增强的问答系统；4）事件抽取','期望学生具有NLP基础，熟悉深度学习框架，有知识图谱相关经验者优先。','每周组会讨论，提供充足的计算资源，鼓励学生参与开源项目。',4,'国家重点研发计划、美团合作项目','与美团、京东有深度合作',NULL,NULL,NULL,NULL,1,6,3,4.70,35,21,1,1,'2026-02-08 21:51:05','2026-02-09 19:08:45'),(15,NULL,'钱学森教授','教授','西安交通大学','电子与信息学部','qian@xjtu.edu.cn',NULL,NULL,'[\"医学图像分析\", \"计算机辅助诊断\", \"深度学习\", \"医疗AI\"]','[\"Medical Imaging\", \"CAD\", \"Healthcare AI\", \"Segmentation\", \"Detection\"]','钱学森教授是西安交大电信学部教授，主要研究医学图像分析和计算机辅助诊断。在MICCAI、TMI、MedIA发表论文40篇。','组内研究方向：1）医学图像分割与检测；2）病理图像分析；3）多模态医学影像融合；4）可解释医疗AI','期望学生具有深度学习基础，对医学AI有兴趣，有图像处理经验者优先。','与多家医院合作，提供真实医学数据，注重培养学生的跨学科能力。',3,'国家自然科学基金重点项目、医院合作项目','与西京医院、华西医院有合作',NULL,NULL,NULL,NULL,1,5,2,4.60,25,15,1,1,'2026-02-08 21:51:05','2026-02-08 22:01:58'),(17,25,'林教授','教授','北京大学','计算机学院','lin@pku.edu.cn',NULL,NULL,'[\"医药分子\"]','[\"医药分子学\", \"药学\"]','专注于医药的药理性研究',NULL,NULL,NULL,0,NULL,NULL,'北大博士',NULL,'https://example.com',NULL,1,5,0,0.00,0,1,1,0,'2026-02-10 18:23:54','2026-02-10 18:24:12');
/*!40000 ALTER TABLE `mentors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) NOT NULL COMMENT '权限名',
  `resource` varchar(200) DEFAULT NULL COMMENT '资源',
  `action` varchar(50) DEFAULT NULL COMMENT '操作',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permission` (`permission_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'mentor:view','mentor','view','2026-02-01 11:53:58'),(2,'mentor:edit','mentor','edit','2026-02-01 11:53:58'),(3,'mentor:delete','mentor','delete','2026-02-01 11:53:58'),(4,'student:view','student','view','2026-02-01 11:53:58'),(5,'student:edit','student','edit','2026-02-01 11:53:58'),(6,'application:create','application','create','2026-02-01 11:53:58'),(7,'application:view','application','view','2026-02-01 11:53:58'),(8,'application:respond','application','respond','2026-02-01 11:53:58'),(9,'rating:create','rating','create','2026-02-01 11:53:58'),(10,'admin:all','admin','all','2026-02-01 11:53:58');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_authors`
--

DROP TABLE IF EXISTS `publication_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_authors` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '关系ID',
  `publication_id` int NOT NULL COMMENT '论文ID',
  `scholar_id` int NOT NULL COMMENT '学者ID',
  `author_order` int DEFAULT '1' COMMENT '作者顺序(1=第一作者)',
  `is_corresponding` tinyint(1) DEFAULT '0' COMMENT '是否通讯作者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pub_scholar` (`publication_id`,`scholar_id`),
  KEY `idx_publication_id` (`publication_id`),
  KEY `idx_scholar_id` (`scholar_id`),
  CONSTRAINT `fk_pub_authors_publication` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pub_authors_scholar` FOREIGN KEY (`scholar_id`) REFERENCES `scholars` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='论文-作者关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_authors`
--

LOCK TABLES `publication_authors` WRITE;
/*!40000 ALTER TABLE `publication_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mentor_id` int NOT NULL COMMENT '导师ID',
  `title` varchar(500) NOT NULL COMMENT '论文标题',
  `authors` text COMMENT '作者列表',
  `venue` varchar(200) DEFAULT NULL COMMENT '发表会议/期刊',
  `year` int DEFAULT NULL COMMENT '发表年份',
  `abstract` text COMMENT '摘要',
  `keywords` json DEFAULT NULL COMMENT '关键词',
  `doi` varchar(200) DEFAULT NULL COMMENT 'DOI',
  `pdf_url` varchar(500) DEFAULT NULL COMMENT 'PDF链接',
  `citation_count` int DEFAULT '0' COMMENT '引用次数',
  `publication_type` varchar(50) DEFAULT NULL COMMENT '类型 (Journal, Conference, Workshop)',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mentor_id` (`mentor_id`),
  KEY `idx_year` (`year`),
  KEY `idx_mentor_year_citation` (`mentor_id`,`year` DESC,`citation_count` DESC),
  CONSTRAINT `publications_ibfk_1` FOREIGN KEY (`mentor_id`) REFERENCES `mentors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学者作品/论文表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
INSERT INTO `publications` VALUES (2,1,'paper','老师1','',2025,'',NULL,'','',0,'Journal','2026-02-03 23:29:07','2026-02-10 20:57:30'),(3,2,'alexpaper','Alex','',2026,'',NULL,'','',0,'Journal','2026-02-04 16:06:19','2026-02-04 16:06:19'),(4,9,'111','111','',2026,'',NULL,'','',0,'Journal','2026-02-10 19:22:11','2026-02-10 19:22:11');
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mentor_id` int NOT NULL COMMENT '导师ID',
  `student_id` int NOT NULL COMMENT '学生ID',
  `rating` decimal(3,1) NOT NULL COMMENT '评分 (0.1-10.0)',
  `comment` text COMMENT '评价内容',
  `aspects` json DEFAULT NULL COMMENT '各方面评分 {"guidance": 5, "communication": 4, "resources": 5}',
  `is_anonymous` tinyint(1) DEFAULT '0' COMMENT '是否匿名',
  `is_verified` tinyint(1) DEFAULT '0' COMMENT '是否认证评价',
  `helpful_count` int DEFAULT '0' COMMENT '有用数',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mentor_id` (`mentor_id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_rating` (`rating`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`mentor_id`) REFERENCES `mentors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='导师评分表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
INSERT INTO `ratings` VALUES (7,1,4,8.0,'<p>hh</p>',NULL,NULL,NULL,0,'2026-02-04 16:21:33','2026-02-04 16:21:33'),(8,12,4,4.0,'<p>nice</p>',NULL,NULL,NULL,0,'2026-02-10 13:56:52','2026-02-10 13:56:52');
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_permission` (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色权限关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,10,'2026-02-01 11:53:58'),(2,1,6,'2026-02-01 11:53:58'),(3,1,8,'2026-02-01 11:53:58'),(4,1,7,'2026-02-01 11:53:58'),(5,1,3,'2026-02-01 11:53:58'),(6,1,2,'2026-02-01 11:53:58'),(7,1,1,'2026-02-01 11:53:58'),(8,1,9,'2026-02-01 11:53:58'),(9,1,5,'2026-02-01 11:53:58'),(10,1,4,'2026-02-01 11:53:58'),(16,2,8,'2026-02-01 11:53:58'),(17,2,7,'2026-02-01 11:53:58'),(18,2,2,'2026-02-01 11:53:58'),(19,2,1,'2026-02-01 11:53:58'),(20,2,4,'2026-02-01 11:53:58'),(23,3,6,'2026-02-01 11:53:58'),(24,3,7,'2026-02-01 11:53:58'),(25,3,1,'2026-02-01 11:53:58'),(26,3,9,'2026-02-01 11:53:58'),(27,3,5,'2026-02-01 11:53:58'),(28,3,4,'2026-02-01 11:53:58');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL COMMENT '角色名',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN','系统管理员','2026-02-01 11:53:58'),(2,'MENTOR','导师','2026-02-01 11:53:58'),(3,'STUDENT','学生','2026-02-01 11:53:58');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scholars`
--

DROP TABLE IF EXISTS `scholars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scholars` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '学者ID',
  `name` varchar(100) NOT NULL COMMENT '姓名',
  `avatar_url` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `institution` varchar(200) DEFAULT NULL COMMENT '所属机构',
  `bio` text COMMENT '个人简介',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `homepage` varchar(255) DEFAULT NULL COMMENT '个人主页',
  `h_index` int DEFAULT '0' COMMENT 'H指数',
  `citation_count` int DEFAULT '0' COMMENT '总引用数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_institution` (`institution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学者表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scholars`
--

LOCK TABLES `scholars` WRITE;
/*!40000 ALTER TABLE `scholars` DISABLE KEYS */;
/*!40000 ALTER TABLE `scholars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '关联用户ID',
  `name` varchar(100) NOT NULL COMMENT '学生姓名',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(50) DEFAULT NULL COMMENT '电话',
  `current_institution` varchar(200) DEFAULT NULL COMMENT '当前学校',
  `major` varchar(100) DEFAULT NULL COMMENT '专业',
  `degree_level` varchar(50) DEFAULT NULL COMMENT '学位级别 (Bachelor, Master, PhD)',
  `graduation_year` int DEFAULT NULL COMMENT '毕业年份',
  `gpa` decimal(3,2) DEFAULT NULL COMMENT 'GPA',
  `research_interests` json DEFAULT NULL COMMENT '研究兴趣列表',
  `keywords` json DEFAULT NULL COMMENT '关键词列表',
  `bio` text COMMENT '个人简介',
  `personal_abilities` text COMMENT '个人能力描述',
  `expected_research_direction` text COMMENT '期望研究方向',
  `preferred_mentor_style` varchar(500) DEFAULT NULL COMMENT '期望导师风格',
  `available_time` varchar(200) DEFAULT NULL COMMENT '可用时间',
  `programming_skills` json DEFAULT NULL COMMENT '编程技能',
  `publications_count` int DEFAULT '0' COMMENT '发表论文数',
  `project_experience` text COMMENT '项目经验',
  `cv_url` varchar(500) DEFAULT NULL COMMENT '简历URL',
  `avatar` varchar(500) DEFAULT NULL COMMENT '头像URL',
  `status` tinyint DEFAULT '1' COMMENT '状态',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_institution` (`current_institution`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学生信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,4,'qqtq','w@163.com',NULL,NULL,'计算机科学','Master',NULL,NULL,'[\"人工智能\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,1,'2026-02-03 22:47:19','2026-02-03 22:47:19'),(2,7,'学生用户',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"医学图像\", \"数据挖掘\"]',NULL,NULL,'深度学习框架,英语四级,数学没基础','与西京医院合作','充分学术自由度','8','[\"python\"]',0,'llm微调',NULL,NULL,1,'2026-02-04 17:48:29','2026-02-09 19:09:31'),(3,8,'testredis','testredis@test.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,1,'2026-02-07 16:52:58','2026-02-07 16:52:58'),(4,9,'alp','1@qq.com',NULL,NULL,NULL,NULL,NULL,NULL,'[\"推荐系统\", \"计算机视觉\"]',NULL,'对人工智能和机器学习有浓厚兴趣的研究生','Python, TensorFlow, PyTorch','大语言模型应用研究','参加国际学术会议','','[\"Python\", \"Java\", \"TensorFlow\"]',0,'',NULL,NULL,1,'2026-02-08 10:57:12','2026-02-08 21:23:02'),(5,16,'王小明','wang_stu@pku.edu.cn',NULL,'北京大学','计算机科学与技术','硕士',2027,3.85,'[\"计算机视觉\", \"深度学习\", \"图像识别\"]','[\"CV\", \"Deep Learning\", \"Image Recognition\", \"CNN\"]','北京大学计算机系硕士研究生，对计算机视觉和深度学习有浓厚兴趣。','具有扎实的数学基础，熟悉PyTorch和TensorFlow，有图像分类项目经验。','希望从事计算机视觉方向的研究，特别是三维重建和神经渲染。','希望导师能够提供充足的指导和计算资源，有定期的一对一讨论。',NULL,'[\"Python\", \"PyTorch\", \"C++\", \"OpenCV\"]',1,'参与过图像分类竞赛，获得省级二等奖；完成过基于深度学习的目标检测项目。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(6,17,'李晓华','li_stu@tsinghua.edu.cn',NULL,'清华大学','人工智能','博士',2028,3.92,'[\"自然语言处理\", \"大语言模型\", \"对话系统\"]','[\"NLP\", \"LLM\", \"Dialogue\", \"Transformer\", \"BERT\"]','清华大学人工智能专业博士研究生，专注于自然语言处理研究。','具有优秀的编程能力和科研能力，已发表2篇顶会论文。','希望深入研究大语言模型的理论和应用，探索更高效的训练方法。','希望有充足的学术自由度，能够参加国际学术会议。',NULL,'[\"Python\", \"PyTorch\", \"Transformers\", \"Linux\"]',2,'参与过多个NLP项目，包括情感分析、文本分类、对话系统等。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(7,18,'张伟','zhang_stu@zju.edu.cn',NULL,'浙江大学','软件工程','硕士',2026,3.78,'[\"推荐系统\", \"机器学习\", \"数据挖掘\"]','[\"RecSys\", \"ML\", \"Data Mining\", \"CTR\", \"Embedding\"]','浙江大学软件工程专业硕士研究生，对推荐系统和数据挖掘感兴趣。','熟悉常见的机器学习算法，有实际的推荐系统开发经验。','希望从事推荐系统方向的研究，探索更精准的个性化推荐算法。','希望能够参与实际的工业项目，积累实践经验。',NULL,'[\"Python\", \"Spark\", \"SQL\", \"TensorFlow\"]',0,'在阿里巴巴实习期间参与推荐系统优化项目。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(8,19,'刘芳','liu_stu@fudan.edu.cn',NULL,'复旦大学','计算机应用技术','硕士',2027,3.88,'[\"强化学习\", \"机器人\", \"自动驾驶\"]','[\"RL\", \"Robotics\", \"Autonomous Driving\", \"Control\", \"Planning\"]','复旦大学计算机应用技术专业硕士研究生，对强化学习和机器人控制感兴趣。','具有良好的数学基础，熟悉强化学习算法，有机器人项目经验。','希望从事强化学习在机器人控制中的应用研究。','希望有机会参与实际的机器人项目，接触真实的硬件平台。',NULL,'[\"Python\", \"ROS\", \"C++\", \"MATLAB\"]',1,'参与过RoboMaster机器人竞赛，负责决策算法开发。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(9,20,'陈杰','chen_stu@sjtu.edu.cn',NULL,'上海交通大学','电子信息','博士',2029,3.95,'[\"推荐系统\", \"计算机视觉\"]','[\"Medical Imaging\", \"Deep Learning\", \"CAD\", \"Segmentation\"]','上海交通大学电子信息专业博士研究生，专注于医学图像分析研究。','Python, TensorFlow, PyTorch，英语四级','大语言模型应用研究','参加国际学术会议','','[\"Python\", \"Java\", \"TensorFlow\"]',1,'',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:54:58'),(10,21,'杨洋','yang_stu@nju.edu.cn',NULL,'南京大学','人工智能','硕士',2026,3.72,'[\"知识图谱\", \"信息抽取\", \"问答系统\"]','[\"Knowledge Graph\", \"IE\", \"QA\", \"NER\", \"Relation Extraction\"]','南京大学人工智能专业硕士研究生，对知识图谱和信息抽取感兴趣。','熟悉NLP基础技术，有知识图谱构建经验。','希望从事知识图谱方向的研究，探索更高效的信息抽取方法。','希望有定期的组会讨论，能够与同学交流学习。',NULL,'[\"Python\", \"Neo4j\", \"SPARQL\", \"HuggingFace\"]',0,'参与过企业知识图谱构建项目，负责实体识别模块。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(11,22,'黄磊','huang_stu@ustc.edu.cn',NULL,'中国科学技术大学','计算机科学','硕士',2027,3.80,'[\"图神经网络\", \"社交网络分析\", \"图表示学习\"]','[\"GNN\", \"Social Network\", \"Graph Learning\", \"Node Classification\"]','中科大计算机科学专业硕士研究生，对图神经网络和社交网络分析感兴趣。','具有良好的数学基础，熟悉图神经网络算法。','希望从事图神经网络方向的研究，探索更强大的图表示学习方法。','希望能够参与实际的数据分析项目。',NULL,'[\"Python\", \"PyTorch Geometric\", \"DGL\", \"NetworkX\"]',0,'参与过社交网络用户行为分析项目。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06'),(12,23,'徐静','xu_stu@hit.edu.cn',NULL,'哈尔滨工业大学','计算机应用技术','博士',2028,3.90,'[\"多模态学习\", \"视觉语言\", \"跨模态检索\"]','[\"Multimodal\", \"Vision-Language\", \"Cross-modal\", \"CLIP\", \"VQA\"]','哈工大计算机应用技术专业博士研究生，专注于多模态学习研究。','具有扎实的深度学习基础，熟悉视觉和语言模型，已发表2篇论文。','希望深入研究多模态学习，探索视觉和语言的深度融合。','希望有充足的计算资源和学术交流机会。',NULL,'[\"Python\", \"PyTorch\", \"Transformers\", \"CUDA\"]',2,'参与过视觉问答和图文匹配项目，在多个数据集上取得SOTA结果。',NULL,NULL,1,'2026-02-08 21:51:06','2026-02-08 21:51:06');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户ID',
  `user_type` varchar(20) NOT NULL COMMENT '用户类型',
  `preference_text` text COMMENT 'LLM生成的偏好描述',
  `preference_keywords` json DEFAULT NULL COMMENT '偏好关键词',
  `preference_topics` json DEFAULT NULL COMMENT '偏好主题',
  `last_analyzed_log_count` int DEFAULT '0' COMMENT '上次分析时的日志数',
  `current_log_count` int DEFAULT '0' COMMENT '当前日志数',
  `analysis_count` int DEFAULT '0' COMMENT '分析次数',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id_type` (`user_id`,`user_type`),
  KEY `idx_update_time` (`update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户偏好分析表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_role` (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,3,'2026-02-01 22:08:04'),(2,2,3,'2026-02-01 22:09:14'),(3,3,2,'2026-02-03 17:00:30'),(4,4,1,'2026-02-03 17:16:47'),(5,5,3,'2026-02-04 15:06:27'),(6,6,1,'2026-02-04 15:24:55'),(7,7,3,'2026-02-04 17:23:22'),(8,8,3,'2026-02-07 16:52:57'),(9,9,3,'2026-02-08 10:57:11'),(11,25,2,'2026-02-10 18:23:54');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码(加密)',
  `salt` varchar(100) DEFAULT NULL COMMENT '盐值',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `user_type` varchar(20) NOT NULL COMMENT '用户类型: student, mentor, admin',
  `status` tinyint DEFAULT '1' COMMENT '状态 (0=禁用, 1=启用)',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_user_type` (`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test_user','$2a$10$zqGgIhWo5pZ4zySPno2LKepkrvh/OtVMHsIdE6xivbH0/JEZ.6Pw.','c8dac6a5-324f-4b0a-9fd7-9e7f0c538177','test@example.com',NULL,'student',1,NULL,'2026-02-01 22:08:04','2026-02-01 22:08:04'),(2,'qqt','$2a$10$wlRe6V0V6GqmcR5baQKqm.jUrxO1LiKIady6E1RWijeU4jhHMy/zq','76855cf9-184b-4ab7-a131-57033edb6de1','a@163.com','','student',1,'2026-02-09 19:11:35','2026-02-01 22:09:15','2026-02-09 19:11:35'),(3,'李翔x','$2a$10$uVYM3hLV0igXubAwVtANwu0MHajLWHpzSG8mV9cg1lLavNtbcsrVu','d8041935-f066-4863-8e1f-fabc46be6974','a1@163.com','','mentor',1,'2026-02-26 16:27:10','2026-02-03 17:00:30','2026-02-26 16:27:10'),(4,'qqtq','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','c7f3d3af-ffbc-4c4b-a497-4d9d1e5af6da','w@163.com',NULL,'admin',1,'2026-02-10 18:20:45','2026-02-03 17:16:48','2026-02-10 18:20:44'),(5,'cookietest','$2a$10$uIohlWlVleM9FvI.Q7s6q.fS3rjqsqi70DyEmeXYafi.w5Nrbi1yK','7fc34f37-d171-4376-860f-258d3528330b','cookietest@example.com',NULL,'student',1,'2026-02-04 15:12:57','2026-02-04 15:06:27','2026-02-04 15:12:57'),(6,'admin2','$2a$10$YrVOWNfyivZRVaWeiak3zu1F.MT5ngQGozq6a/C/O1Or05rbFgJxO','978911d1-b84f-4ff6-8286-8fd04eafa2a1','admin2@example.com',NULL,'admin',1,'2026-02-04 15:25:13','2026-02-04 15:24:56','2026-02-04 15:25:12'),(7,'qstu','$2a$10$gUA0S9bBCoG1pZPXBSEzg.RqDuzfF8lUj01xvB3CA4qcfTnHds1Zq','431da7c1-c15d-463d-9d56-ee307b3cd988','xx@163.com',NULL,'student',1,'2026-02-06 14:31:13','2026-02-04 17:23:22','2026-02-06 14:31:13'),(8,'testredis','$2a$10$FIDHSpjPR7bS2bVxNH2tV.Razp.vYRDIRC7OirO3PVSwfrtzI408W','82472c4c-e197-40b4-950f-1fd93f0b0708','testredis@test.com',NULL,'student',1,'2026-02-07 16:53:12','2026-02-07 16:52:58','2026-02-07 16:53:12'),(9,'alp','$2a$10$ACnuqkzsoNbZ.OM7LLXLa.elqkC5XA5sVz0ai8UIjth/2MMvvGiQK','6be27650-5725-4336-999f-3f83443537d1','1@qq.com',NULL,'student',1,'2026-02-08 21:41:35','2026-02-08 10:57:12','2026-02-08 21:41:34'),(10,'mentor_zhao','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb8377dd-04f5-11f1-a5af-1418772a401b','zhao@pku.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(11,'mentor_sun','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb838131-04f5-11f1-a5af-1418772a401b','sun@fudan.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(12,'mentor_wu','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb8384e3-04f5-11f1-a5af-1418772a401b','wu@nju.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(13,'mentor_zhou','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb838747-04f5-11f1-a5af-1418772a401b','zhou@ustc.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(14,'mentor_zheng','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb83896d-04f5-11f1-a5af-1418772a401b','zheng@hit.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(15,'mentor_qian','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb838b80-04f5-11f1-a5af-1418772a401b','qian@xjtu.edu.cn',NULL,'mentor',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(16,'student_wang','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb838d7a-04f5-11f1-a5af-1418772a401b','wang_stu@pku.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(17,'student_li','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb838f75-04f5-11f1-a5af-1418772a401b','li_stu@tsinghua.edu.cn',NULL,'student',1,'2026-02-10 16:56:31','2026-02-08 21:51:05','2026-02-10 16:56:31'),(18,'student_zhang','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb83918c-04f5-11f1-a5af-1418772a401b','zhang_stu@zju.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(19,'student_liu','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb83938c-04f5-11f1-a5af-1418772a401b','liu_stu@fudan.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(20,'student_chen','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb83957a-04f5-11f1-a5af-1418772a401b','chen_stu@sjtu.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(21,'student_yang','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb839867-04f5-11f1-a5af-1418772a401b','yang_stu@nju.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(22,'student_huang','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb839a6c-04f5-11f1-a5af-1418772a401b','huang_stu@ustc.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(23,'student_xu','$2a$10$YIqLDgRMnWRISg31KwaFo.clOw8bM4HeIEXm74tKKCaaFYyUOyGMa','bb839c5b-04f5-11f1-a5af-1418772a401b','xu_stu@hit.edu.cn',NULL,'student',1,NULL,'2026-02-08 21:51:05','2026-02-08 21:54:48'),(25,'mentor_lin','$2a$10$k0ZFhcTsJewAxwpIK905JO0ccHCeorIvcISCWXjPYeuehdoLgXTl2','d2a33241-9c71-483f-a062-24df44945cc2','lin@pku.edu.cn',NULL,'mentor',1,NULL,'2026-02-10 18:23:54','2026-02-10 18:23:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-27 14:58:13
